# ThresholdR 0.1.0 - vendored copy

## What this is

A source package rebuilt from the ThresholdR binary that was installed in the
analysis environment on 2026-03-29 under R 4.4.3. No source tarball or install
record was kept at the time, so the R code here was recovered by deparsing the
package's lazy-load database. Every function round-trips to code identical to
the installed binary (verified by comparing deparsed formals and bodies).

Comments, roxygen blocks and original source formatting could not be recovered.
The help pages under `man/` were regenerated from the installed help database
and are the original documentation text.

## Upstream

Upstream is <https://github.com/MDMotlagh/ThresholdR> (MIT, Mohammad
Oliaeimotlagh). The installed copy recorded no Repository, RemoteUrl or
RemoteSha field, so R kept no origin for it.

## This copy is NOT identical to upstream

Two differences were found when comparing against upstream commit
9b639507d76e5348afda9ff633ca6c652bbd01b3 (the newest commit on `main` that
predates the 2026-03-29 install date):

1. `get_thresholds()` here calls an internal helper `.intersect2mix()` to find
   the crossing point of two Gaussian components. Upstream calls
   `AdaptGauss::Intersect2Mixtures(...)$CutX` instead. The two are different
   algorithms: `.intersect2mix()` solves `w1*dnorm(x,m1,s1) == w2*dnorm(x,m2,s2)`
   with `uniroot()` between the two means, falling back to a 10000-point grid
   search; `AdaptGauss::Intersect2Mixtures()` scans a 20000-point grid over
   `[min(mu)-2*sd, max(mu)+2*sd]` and returns the point of minimum absolute
   difference. They can return different cut values.
2. `DESCRIPTION` here imports `mixtools, mclust, foreach, ggplot2`. Upstream
   also imports `AdaptGauss`.

So the `bi_cut`, `tri_cut1` and `tri_cut2` columns produced by
`get_thresholds()` are NOT guaranteed to match a fresh install from upstream
`main`. The `bi_thr`, `tri_thr1` and `tri_thr2` columns (mean + 3*sigma of the
noise component) are computed the same way in both and are unaffected. The
pipeline's step 5a gating uses the mean + 3*sigma rule.

No upstream commit was found whose `DESCRIPTION` matches the installed one, so
the installed build is treated as a local patch of upstream, not as a plain
checkout.

## Changes made while rebuilding

* Removed the install-time `Built:`, `Author:` and `Maintainer:` fields from
  `DESCRIPTION` (R regenerates them on install).
* Removed a trailing comma after `ggplot2` in the `Imports:` field. The
  dependency list is unchanged.

* In `man/publish_fittings_thr.Rd` the example's `path=` argument was an
  absolute path on the original author's own machine. It was replaced with the
  relative `'plots/'`. This is documentation text only; no code changed.

Nothing else was edited. R code, `NAMESPACE` and `LICENSE` are as recovered.
